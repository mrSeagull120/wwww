var input;
var button;
var slider;
function setup() {
  createCanvas(400, 400);
  button = createButton('Click me!');
  slider = createSlider(0, 400);
  input  = createInput('Your name');
  createP('In order to inisiate the process, please start with typing your name correctly in the "your name" input box');
    createP('Make sure for the name to be typed CORRECTLY, if not the program will not work');
}
function draw() {
  background(220);
  ellipse(slider.value(), 200, 100, 100);
  button.mousePressed(changeColour);
  textSize(50);
  text(input.value(), 50, 50);
  input.html('')
  if(input.value() == 'Stefan'){
    text('I know you', 100, 340);
  }
    if(input.value() == 'Andrei'){
    text('I know u too', 100, 340);
  }
    if(input.value() == 'How?'){
    text('hehe', 100, 340);
  }
}
function changeColour(){
    ellipse(slider.value(), 200, 100, 100);
  fill(random(255), random(255), random(255));
}